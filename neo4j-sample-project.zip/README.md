# Neo4j Sample Project

This repository demonstrates my learning and practice of **Neo4j** using **Cypher queries**.

## Contents
- `cypher-queries/` → Example queries (CREATE, MATCH, MERGE, etc.)
- `dataset/` → Sample graph data to load into Neo4j

## Use Case
Academic learning: practicing Cypher, graph data modeling, and small example projects such as knowledge graphs and recommendations.

## Example
```cypher
// Find all movies directed by Christopher Nolan
MATCH (d:Director {name: "Christopher Nolan"})-[:DIRECTED]->(m:Movie)
RETURN m.title;
```
